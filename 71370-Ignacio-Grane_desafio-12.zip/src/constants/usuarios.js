const usuarios = [
  {
    id: 1,
    nombre: "Nacho",
    apellido: "Lopez",
    edad: 34,
    colorFavorito: "azul",
  },
  {
    id: 2,
    nombre: "Manuel",
    apellido: "Ferrari",
    edad: 22,
    colorFavorito: "naranja",
  },
  {
    id: 3,
    nombre: "Lucia",
    apellido: "Gomez",
    edad: 25,
    colorFavorito: "violeta",
  },
  {
    id: 4,
    nombre: "Carmen",
    apellido: "Richi",
    edad: 37,
    colorFavorito: "amarillo",
  },
  {
    id: 5,
    nombre: "Silvina",
    apellido: "Hernandez",
    edad: 41,
    colorFavorito: "rojo",
  },
];

export default usuarios;
